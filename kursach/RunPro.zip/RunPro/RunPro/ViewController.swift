//
//  ViewController.swift
//  RunPro
//
//  Created by Арам on 01.05.2022.
//

import UIKit
import CoreMotion
import FirebaseDatabase

class ViewController: UIViewController {

    @IBOutlet weak var stCounter: UILabel!
    
    @IBOutlet weak var dtCounter: UILabel!
    
    let activityManager = CMMotionActivityManager()
    let pedoMeter = CMPedometer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if CMMotionActivityManager.isActivityAvailable() {
            self.activityManager.startActivityUpdates(to: OperationQueue.main) { (data) in
                DispatchQueue.main.async {
                    if  let activity = data{
                        if activity.running == true {
                            print("Running")
                        }else if activity.walking == true{
                            print("Walking")
                        }else if activity.automotive == true {
                            print("Automative")
                        }
                            
                    }
                }
            }
        }
        if CMPedometer.isStepCountingAvailable() && CMPedometer.isDistanceAvailable(){
            self.pedoMeter.startUpdates(from: Date()) { (data, error) in
                if error == nil {
                    if let response = data {
                        DispatchQueue.main.async {
                            print("Steps: \(response.numberOfSteps)")
                            print(String("Distance: \(response.distance)"))
                            self.stCounter.text = "\(response.numberOfSteps) steps"
                            
                            let strr = String("\(response.distance)")
                            let distsub = strr.suffix(18).prefix(6)
                            self.dtCounter.text = String("\(distsub) metres")
                        }
                    }
                }
            }
        }
    }
    @IBAction func button(_ sender: UIButton) {
        let today = "\(NSDate())"
        Database.database().reference().child(today).child("Steps").setValue(self.stCounter.text!)
        Database.database().reference().child(today).child("Distance").setValue(self.dtCounter.text!)
        print(NSDate())
        }
}

