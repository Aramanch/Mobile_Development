//
//  HistoryViewController.swift
//  RunPro
//
//  Created by Арам on 03.05.2022.
//

import UIKit
import FirebaseDatabase

class HistoryViewController: UIViewController{
    
    

    
    //@IBOutlet weak var history: UILabel!
    //@IBOutlet weak var history: UILabel!
    
   
    @IBOutlet weak var history: UILabel!
    //@IBOutlet weak var historyst: UILabel!
    //@IBOutlet weak var historyst: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Database.database().reference().observeSingleEvent(of: .value , with: { snapshot in

           if snapshot.exists() {

               let recent = snapshot.value
               
               let stroka = "\(String(describing: recent))"
               
               print(stroka)
               
               
//               let subst = stroka.suffix(40)
//               let substt = subst.prefix(3)
               
               let substsp = stroka.suffix(70).prefix(60)
               
               self.history.text = String("\(substsp)")
               //self.historyst.text = String("Today: \(substsp)")
               
       }
      
     
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

)}
}
