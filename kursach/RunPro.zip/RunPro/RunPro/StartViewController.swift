//
//  StartViewController.swift
//  RunPro
//
//  Created by Арам on 02.05.2022.
//

import UIKit

class StartViewController: UIViewController {
    var myImageView = UIImageView()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "welcome")
        backgroundImage.contentMode = .scaleAspectFill
        view.insertSubview(backgroundImage, at: 0)

    }

}
























