package com.example.datastorage;

import androidx.appcompat.app.AppCompatActivity;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button btnSave, btnLoad;
    EditText etName;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        View.OnClickListener clickListenerUp = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = "";
                switch (v.getId()) {
                    case R.id.btnSave:
                        saveText();
                        break;
                    case R.id.btnLoad:
                        loadText();
                        break;
                    default:
                        break;


                }
            }};

        btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(clickListenerUp );
        btnLoad = findViewById(R.id.btnLoad);
        btnLoad.setOnClickListener(clickListenerUp);
        etName = findViewById(R.id.etName);


        loadText();
    }
    private void saveText() {
        SharedPreferences.Editor ed = getPreferences(MODE_PRIVATE).edit();
        String name = etName.getText().toString();
        ed.putString("name", name);
        ed.commit();
        Log.i("SPREF", name);
        Toast.makeText(MainActivity.this, "Текст сохранён", Toast.LENGTH_SHORT).show();

    }
    private void loadText() {
        SharedPreferences pref = getPreferences(MODE_PRIVATE);
        String name = pref.getString("name", "");
        etName.setText(name);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveText();

    }
}